#PUC GO Big Data
#Programação e Estrutura de Dados
#FORCA para jogar com seu amigo, por Rosemeiry de Queiroz Chaves
import random
import time
min=1
max=6
frutas = ['abacaxi','laranja','melancia','jabuticaba','pessego','framboesa','ameixa','maracuja','abacate','tangerina','morango','acerola' ]
carros = ['pajero','camaro','amarok','sandero','strada','saveiro','fusca','voyage','ecosport','fiorino','corolla','chevette','delorian']
comidas = ['strogonofe','macarronada','galinhada','feijoada','fricasse','lasanha','salada','ambrosia','sorvete','pamonha','risoto']
de_novo='yes'
x=0
v=1
char="w"
#Rolando os dados para ver o jogador que começa
print ("Vamos jogar FORCA !!! Entre com o nome dos 2 jogadores: ")
#Coletando o nome dos jogadores
nome1=input("     Informe o nome do Jogador 1: ") 
nome2=input("     Informe o nome do Jogador 2: ")
#Lançando os dados
for y in de_novo:
  x=(random.randint(min, max))
  v=(random.randint(min, max))
  print ("     Vamos lançar os dados e ver quem começa!") 
  print ('     Resultado: ', x, 'para',nome1,'e', v, 'para ',nome2)
  if x>v:
    print ('    ',nome1,'Hora de jogar! Vamos lá!')
    de_novo='nao'
    break
  elif v>x:
    print ('    ',nome2,'Hora de jogar! Vamos lá!')
    de_novo='nao'
    break
  else:
    print ('Empatou!!! Não tem problema.')
    de_novo='y'
#Começar a Forca
#Escolher a categoria 
print ("")
print ('Quer escolher a categoria?')
categoria=input ('a- carro, s -comida, d -fruta: ')
for i in categoria:
  if i=='a':
    palavra=(random.choice(carros))
  elif i=='s':
    palavra=(random.choice(comidas))
  else :
    palavra=(random.choice(frutas))
print ("")
#aguarda 1 segundo
time.sleep(0.5)
#escolhe a palavra a adivinhar
print ('Comece a adivinhar a PALAVRA SECRETA, letra por letra')
print ('Veja a posição de cada LETRA _ na PALAVRA _ _ _')
print ('Digite a PALAVRA TODA e GANHE o jogo!!!!!')
print ("")
#Aqui uma variável com valor vazio
adivinha=''
#Determinando o número de chances
vezes = 10
# Criando um laço while e checando se ainda há chances >0
while vezes > 0:        
    # fazer um contador que comece com zero
    falha = 0            
    #para cada caractere da palavra secreta    
    for char in palavra:      
    # veja se o caractere está na escolha do jogador
        if char in adivinha:    
        # imprima confirmação da letra na palavra
          print ('Sim,',char,'está na PALAVRA :)')
        else:   
        # se não encontrado, imprima um traço
          print ("_")    
        # e aumente o contador de falhas em um
          falha +=1    
  # Será que está certo?
  #Se falha = 0 você venceu
    if falha == 0:
        #A palavra começando com maiúscula
        print('Parabéns,',str.capitalize(palavra),' é a PALAVRA!')  
        time.sleep(0.5)
        #Tracinhos separadores
        linha = '-' * 50
        print(linha)
        time.sleep(1)
        print("Você venceu , gênio !!!")
        time.sleep(0.5)
        print('.......................')
        time.sleep(0.5)
        print('........___O___........')
        time.sleep(0.5)
        print('...........|...........')
        time.sleep(0.5)
        print('........../.\..........')
        time.sleep(0.5)
        print('........./...\.........')
        time.sleep(0.5)
        print('.......................')
        time.sleep(0.5)
        print('. SE LIVROU DA FORCA !.')
    # saída
        break              
    # peça ao usuário que adivinhe um caractere
    linha = '-' * 50
    print(linha)
    adivinha = input("Arrisque a PALAVRA ou digite uma LETRA : ")
    # Analisa a adivinhação do usuário
    # se a adivinha não está na palavra secr eta
    if adivinha not in palavra:   
     # contador de vezes diminui 1 
        vezes -= 1        
     # Imprime Errou
        print ("Errado, a LETRA", adivinha,"não está na palavra!")    
     # Quantas chances você ainda tem 
        print ("Quantas chances você tem: ", vezes,)
     # se as chances forem zero
        if vezes == 0:          
           # imprime "você perdeu, e sentencia à forca"
            print ("")
            print('Lamento,você perdeu :(')
            print('A palavra era',str.capitalize(palavra))
            print (linha)
            print('SUA SENTENÇA: FORCA')
            time.sleep(0.5)
            print('...................')
            time.sleep(0.5)
            print('...... __.__.O.....')
            time.sleep(0.5)
            print('.........|.........') 
            time.sleep(0.5)
            print('......../.\........') 
            time.sleep(0.5)
            print('......./...\.......') 
            time.sleep(0.5)
            print('...................')
